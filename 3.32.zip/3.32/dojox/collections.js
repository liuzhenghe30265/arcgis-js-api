//>>built
define("dojox/collections",["./collections/_base"],function(a){return a});