//>>built
define("dojox/validate",["./validate/_base"],function(a){return a});