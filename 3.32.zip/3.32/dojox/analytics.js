//>>built
define("dojox/analytics",["./analytics/_base"],function(a){return a});