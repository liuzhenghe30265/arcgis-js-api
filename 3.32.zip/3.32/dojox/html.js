//>>built
define("dojox/html",["./html/_base"],function(a){return a});