//>>built
define("dojox/timing",["./timing/_base"],function(a){return a});