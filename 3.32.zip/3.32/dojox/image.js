//>>built
define("dojox/image",["./image/_base"],function(a){return a});