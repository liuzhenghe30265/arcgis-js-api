//>>built
define("dojox/mvc",["./mvc/_base"],function(a){return a});