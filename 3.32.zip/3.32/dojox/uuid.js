//>>built
define("dojox/uuid",["dojox/uuid/_base"],function(a){return a});