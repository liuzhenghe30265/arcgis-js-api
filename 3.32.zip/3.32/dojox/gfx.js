//>>built
define("dojox/gfx",["dojo/_base/lang","./gfx/_base","./gfx/renderer!"],function(c,a,b){a.switchTo(b);return a});