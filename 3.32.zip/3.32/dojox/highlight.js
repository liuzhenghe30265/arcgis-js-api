//>>built
define("dojox/highlight",["./highlight/_base"],function(a){return a});