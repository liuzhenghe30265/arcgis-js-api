//>>built
define("dojox/dtl",["./dtl/_base"],function(a){return a});