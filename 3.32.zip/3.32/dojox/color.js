//>>built
define("dojox/color",["./color/_base"],function(a){return a});