// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.32/esri/copyright.txt for details.
//>>built
define("esri/tasks/LegendLayer",["dojo/_base/declare","dojo/_base/lang","dojo/has","../kernel"],function(a,b,c,d){a=a(null,{declaredClass:"esri.tasks.LegendLayer",layerId:null,subLayerIds:null});c("extend-esri")&&b.setObject("tasks.LegendLayer",a,d);return a});