// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.32/esri/copyright.txt for details.
//>>built
define("esri/tasks/ParameterValue",["dojo/_base/declare","dojo/_base/lang","dojo/has","../kernel"],function(a,b,c,d){a=a(null,{declaredClass:"esri.tasks.ParameterValue",constructor:function(a){b.mixin(this,a)}});c("extend-esri")&&b.setObject("tasks.ParameterValue",a,d);return a});