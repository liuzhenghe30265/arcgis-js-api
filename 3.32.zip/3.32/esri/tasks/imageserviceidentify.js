// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.32/esri/copyright.txt for details.
//>>built
define("esri/tasks/imageserviceidentify",["./ImageServiceIdentifyTask","./ImageServiceIdentifyParameters","./ImageServiceIdentifyResult"],function(){return{}});