// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.32/esri/copyright.txt for details.
//>>built
define("esri/IdentityManager",["./IdentityManagerDialog","./kernel","./OAuthSignInHandler","dojo/_base/declare"],function(a,b,c,d){a=new a;b.id=d.safeMixin(a,c);return b.id});