// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.32/esri/copyright.txt for details.
//>>built
define("esri/extend",["dojo/_base/lang","dojo/has","./kernel"],function(b,c,d){return function(a,e){c("extend-esri")&&(a=a.substring(a.indexOf(".")+1),b.setObject(a,e,d))}});