// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.32/esri/copyright.txt for details.
//>>built
define("esri/renderer","./renderers/Renderer ./renderers/SimpleRenderer ./renderers/UniqueValueRenderer ./renderers/ClassBreaksRenderer ./renderers/TemporalRenderer ./renderers/SymbolAger ./renderers/TimeClassBreaksAger ./renderers/TimeRampAger ./renderers/StretchRenderer ./renderers/jsonUtils".split(" "),function(a,b,c,d,e,f,g,h,k,l){return{Renderer:a,SimpleRenderer:b,UniqueValueRenderer:c,ClassBreaksRenderer:d,TemporalRenderer:e,SymbolAger:f,TimeClassBreaksAger:g,TimeRampAger:h,StretchRenderer:k,
jsonUtils:l}});