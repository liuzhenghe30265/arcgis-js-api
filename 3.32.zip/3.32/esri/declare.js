// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.32/esri/copyright.txt for details.
//>>built
define("esri/declare",["dojo/_base/declare","dojo/_base/lang","./extend"],function(e,f,g){return function(b,a,c){var d=f.isString(b);d?c.declaredClass=b:(c=a,a=b);a=e(a,c);d&&g(b,a);return a}});