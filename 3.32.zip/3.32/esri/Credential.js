// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.32/esri/copyright.txt for details.
//>>built
define("esri/Credential",["dojo/_base/declare","dojo/has","./kernel","./IdentityManagerBase"],function(a,b,c,d){a=a(d.Credential,{});b("extend-esri")&&(c.Credential=a);return a});